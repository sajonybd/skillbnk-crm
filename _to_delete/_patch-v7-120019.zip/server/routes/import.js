import { Router } from 'express';
import { HttpError, tx } from '../db.js';
import { analyze, buildLeads, dedupeKey, IMPORT_FIELDS } from '../lib/importer.js';
import { createPlaceholderUser } from './team.js';
import { createMeeting } from '../lib/meetings.js';
import { TEAM } from '../config.js';

const COLS = [
  'first_name', 'last_name', 'title', 'company', 'email', 'email_status', 'phone', 'linkedin',
  'company_linkedin', 'website', 'employees', 'industry', 'city', 'state', 'country', 'source',
  'icp_segment', 'stage', 'quality', 'next_action', 'next_action_date', 'notes', 'apollo_id',
];

// Accepts 2026-11-05 or any date text JS can read ("Nov 5, 2026"); returns YYYY-MM-DD or ''.
function meetingDate(v) {
  const t = String(v || '').trim();
  if (!t) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(t)) return t;
  const ms = Date.parse(t + ' 12:00 UTC');
  return Number.isNaN(ms) ? '' : new Date(ms).toISOString().slice(0, 10);
}

export function importRoutes(db) {
  const r = Router();
  const exists = db.prepare('SELECT 1 FROM leads WHERE dedupe_key = ?');
  const inBin = db.prepare("SELECT 1 FROM leads WHERE dedupe_key = ? AND deleted_at != ''");

  // Step 1 — read the file, guess the column mapping, count new vs duplicate rows.
  r.post('/preview', (req, res) => {
    const { text } = req.body || {};
    if (!text || !String(text).trim()) throw new HttpError(400, 'Paste some data or choose a file first');
    const a = analyze(text);
    if (a.headers.length === 0) throw new HttpError(400, 'Could not read any rows');
    const { leads, invalid } = buildLeads(a.rows, a.mapping);
    const seen = new Set();
    let fresh = 0;
    let dupes = 0;
    let trashed = 0;
    for (const l of leads) {
      const k = dedupeKey(l);
      if (inBin.get(k)) trashed++;
      if (seen.has(k) || exists.get(k)) dupes++;
      else { fresh++; seen.add(k); }
    }
    res.json({
      headers: a.headers,
      mapping: a.mapping,
      fields: IMPORT_FIELDS,
      totalRows: a.rows.length,
      newCount: fresh,
      duplicateCount: dupes,
      trashedCount: trashed,
      invalidCount: invalid,
      sample: a.rows.slice(0, 5),
    });
  });

  // Step 2 — import for real.
  // assign: { mode: 'none' | 'user' | 'split', user_ids: [] }
  r.post('/commit', (req, res) => {
    const { text, mapping, source, assign } = req.body || {};
    if (!text || !Array.isArray(mapping)) throw new HttpError(400, 'Missing data');
    const a = analyze(text);
    const { leads, invalid } = buildLeads(a.rows, mapping);

    const mode = assign?.mode || 'none';
    const pool = (assign?.user_ids || []).map(Number).filter(Boolean);
    if (mode !== 'none' && pool.length === 0) throw new HttpError(400, 'Pick at least one team member to assign to');
    for (const id of pool) {
      if (!db.prepare('SELECT 1 FROM users WHERE id = ? AND active = 1').get(id)) throw new HttpError(400, 'Unknown team member');
    }

    const result = { totalRows: a.rows.length, created: 0, duplicates: 0, inBin: 0, invalid, createdUsers: [], unknownOwners: {}, byOwner: {} };
    const ownerCache = new Map(); // lowercase name/email → user id
    const nameOf = new Map();
    const findUser = db.prepare('SELECT id, name FROM users WHERE LOWER(name) = ? OR LOWER(email) = ?');

    const resolveOwner = (raw) => {
      const k = raw.toLowerCase();
      if (ownerCache.has(k)) return ownerCache.get(k);
      let u = findUser.get(k, k);
      // Only people on the configured team get an account automatically. Any other name in the
      // Owner column (e.g. "TO CONFIRM") is not turned into a user: the lead is imported unassigned.
      if (!u && !TEAM.some((m) => m.name.toLowerCase() === k)) { ownerCache.set(k, null); return null; }
      if (!u) { u = createPlaceholderUser(db, raw); result.createdUsers.push(raw); }
      ownerCache.set(k, u.id);
      nameOf.set(u.id, u.name);
      return u.id;
    };

    const cols = [...COLS, 'dedupe_key', 'owner_id', 'created_at', 'updated_at'];
    const insert = db.prepare(
      `INSERT OR IGNORE INTO leads(${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`
    );
    const poolNames = new Map(pool.map((id) => [id, db.prepare('SELECT name FROM users WHERE id = ?').get(id).name]));
    const now = new Date().toISOString();
    const label = String(source || '').trim();
    let rr = 0;

    tx(db, () => {
      for (const l of leads) {
        if (label && !l.source) l.source = label;
        let ownerId = null;
        let viaSplit = false;
        if (l.owner) {
          ownerId = resolveOwner(l.owner);
          if (ownerId === null) result.unknownOwners[l.owner] = (result.unknownOwners[l.owner] || 0) + 1;
        }
        else if (mode === 'user') ownerId = pool[0];
        else if (mode === 'split') { ownerId = pool[rr % pool.length]; viaSplit = true; }
        const vals = COLS.map((c) => (c === 'stage' ? l.stage || 'New' : l[c] ?? ''));
        const info = insert.run(...vals, dedupeKey(l), ownerId, now, now);
        if (info.changes === 0) {
          result.duplicates++;
          if (inBin.get(dedupeKey(l))) result.inBin++;
          continue;
        }
        if (viaSplit) rr++;
        result.created++;
        const md = meetingDate(l.meeting_date);
        if (md) {
          const leadId = Number(db.prepare('SELECT id FROM leads WHERE dedupe_key = ?').get(dedupeKey(l)).id);
          // Old meetings count towards the week they were scheduled in, not this week's KPI.
          const createdAt = new Date(Math.min(Date.now(), Date.parse(md + 'T06:00:00Z'))).toISOString();
          createMeeting(db, { id: leadId, owner_id: ownerId }, { scheduled_date: md, booked_by: ownerId || req.user.id }, req.user, { quiet: true, createdAt });
          db.prepare("UPDATE leads SET stage = CASE WHEN stage IN ('New','Contacted','Replied') THEN 'Meeting Booked' ELSE stage END WHERE id = ?").run(leadId);
        }
        const nm = ownerId ? nameOf.get(ownerId) || poolNames.get(ownerId) : 'Unassigned';
        result.byOwner[nm] = (result.byOwner[nm] || 0) + 1;
      }
    });
    res.json(result);
  });

  return r;
}
