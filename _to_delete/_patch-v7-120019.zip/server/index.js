import { createApp } from './app.js';
import { openDb } from './db.js';
import { seedAdmin, seedTeam } from './auth.js';
import { DB_FILE, PORT, DEFAULT_ADMIN, TEAM_DEFAULT_PASSWORD } from './config.js';

const db = openDb(DB_FILE);
if (seedAdmin(db)) {
  console.log('\nFirst run: created admin account');
  console.log(`  email:    ${DEFAULT_ADMIN.email}`);
  console.log(`  password: ${DEFAULT_ADMIN.password}`);
  console.log('  Sign in and change the password (top right → Password).\n');
}
const madeTeam = seedTeam(db);
if (madeTeam.length) console.log(`Created team members: ${madeTeam.join(', ')} (password: ${TEAM_DEFAULT_PASSWORD}). Update emails/passwords in the Team page.\n`);
createApp(db).listen(PORT, () => console.log(`skillBNK CRM running → http://localhost:${PORT}`));
