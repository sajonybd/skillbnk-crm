import express from 'express';
import { PUBLIC_DIR, STAGES, QUALITIES, MANUAL_TYPES, TYPE_LABELS, TZ, TOUCH_TYPES, LINKEDIN_TYPES, MEETING_STATUSES, LINK_KINDS, DEFAULT_WEEKLY_MEETING_TARGET } from './config.js';
import { attachUser, authRoutes, requireAuth } from './auth.js';
import { leadsRoutes } from './routes/leads.js';
import { activityRoutes } from './routes/activity.js';
import { teamRoutes } from './routes/team.js';
import { importRoutes } from './routes/import.js';
import { meetingsRoutes } from './routes/meetings.js';
import { kpiRoutes } from './routes/kpi.js';
import { RANGES } from './lib/range.js';

export function createApp(db) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '50mb' }));
  app.use(attachUser(db));

  app.use('/api', authRoutes(db));
  app.get('/api/config', requireAuth, (_req, res) =>
    res.json({ stages: STAGES, qualities: QUALITIES, manualTypes: MANUAL_TYPES, typeLabels: TYPE_LABELS, ranges: RANGES, tz: TZ, touchTypes: TOUCH_TYPES, linkedinTypes: LINKEDIN_TYPES, meetingStatuses: MEETING_STATUSES, linkKinds: LINK_KINDS, defaultTarget: DEFAULT_WEEKLY_MEETING_TARGET })
  );
  app.use('/api/leads', requireAuth, leadsRoutes(db));
  app.use('/api/activity', requireAuth, activityRoutes(db));
  app.use('/api/meetings', requireAuth, meetingsRoutes(db));
  app.use('/api/kpi', requireAuth, kpiRoutes(db));
  app.use('/api/team', requireAuth, teamRoutes(db));
  app.use('/api/import', requireAuth, importRoutes(db));
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

  app.use(express.static(PUBLIC_DIR));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    const status = err.status || 500;
    if (status >= 500) console.error(err);
    res.status(status).json({ error: status >= 500 ? 'Something went wrong' : err.message });
  });
  return app;
}
