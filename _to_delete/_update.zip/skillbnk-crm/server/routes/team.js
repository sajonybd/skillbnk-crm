import crypto from 'node:crypto';
import { Router } from 'express';
import { hashPassword, requireAdmin } from '../auth.js';
import { HttpError } from '../db.js';

export function teamRoutes(db) {
  const r = Router();

  r.get('/', (_req, res) => {
    const users = db.prepare(
      `SELECT u.id, u.name, u.email, u.role, u.active,
              (SELECT COUNT(*) FROM leads l WHERE l.owner_id = u.id) AS lead_count
       FROM users u ORDER BY u.active DESC, u.name`
    ).all();
    res.json({ users });
  });

  r.post('/', requireAdmin, (req, res) => {
    const { name, email, password, role } = req.body || {};
    if (!String(name || '').trim() || !String(email || '').trim()) throw new HttpError(400, 'Name and email are required');
    if (!password || String(password).length < 6) throw new HttpError(400, 'Password must be at least 6 characters');
    try {
      const info = db.prepare(
        'INSERT INTO users(name, email, password_hash, role, active, created_at) VALUES (?,?,?,?,1,?)'
      ).run(String(name).trim(), String(email).trim(), hashPassword(password), role === 'admin' ? 'admin' : 'member', new Date().toISOString());
      res.status(201).json({ id: Number(info.lastInsertRowid) });
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'A user with that name or email already exists');
      throw e;
    }
  });

  r.patch('/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!u) throw new HttpError(404, 'User not found');
    const { name, email, role, active, password } = req.body || {};
    if (id === req.user.id && (active === false || active === 0 || (role && role !== 'admin'))) {
      throw new HttpError(400, "You can't deactivate or demote yourself");
    }
    const next = {
      name: name != null ? String(name).trim() : u.name,
      email: email != null ? String(email).trim() : u.email,
      role: role ? (role === 'admin' ? 'admin' : 'member') : u.role,
      active: active != null ? (active ? 1 : 0) : u.active,
      password_hash: password ? hashPassword(password) : u.password_hash,
    };
    if (password && String(password).length < 6) throw new HttpError(400, 'Password must be at least 6 characters');
    try {
      db.prepare('UPDATE users SET name=?, email=?, role=?, active=?, password_hash=? WHERE id=?')
        .run(next.name, next.email, next.role, next.active, next.password_hash, id);
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'A user with that name or email already exists');
      throw e;
    }
    res.json({ ok: true });
  });

  return r;
}

// Used by the importer when a sheet names an owner that has no account yet.
export function createPlaceholderUser(db, name) {
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '') || 'user';
  let email = `${slug}@skillbnk.local`;
  let n = 1;
  while (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) email = `${slug}${++n}@skillbnk.local`;
  const info = db.prepare(
    'INSERT INTO users(name, email, password_hash, role, active, created_at) VALUES (?,?,?,?,1,?)'
  ).run(name, email, hashPassword(crypto.randomBytes(12).toString('hex')), 'member', new Date().toISOString());
  return { id: Number(info.lastInsertRowid), name };
}
