import { Router } from 'express';
import { STAGES, QUALITIES, MANUAL_TYPES, FIRST_TOUCH_TYPES } from '../config.js';
import { HttpError, logActivity, tx } from '../db.js';
import { dedupeKey, hasIdentity } from '../lib/leadkey.js';

const TEXT_FIELDS = [
  'first_name', 'last_name', 'title', 'company', 'email', 'email_status', 'phone',
  'linkedin', 'company_linkedin', 'website', 'employees', 'industry', 'city', 'state',
  'country', 'source', 'icp_segment', 'notes', 'next_action',
];
const DATE_FIELDS = ['meeting_date', 'next_action_date'];
const SORTABLE = new Set([
  'updated_at', 'created_at', 'last_activity_at', 'company', 'first_name',
  'next_action_date', 'meeting_date', 'stage', 'quality',
]);
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const label = (f) => f.replace(/_/g, ' ');

export function leadsRoutes(db) {
  const r = Router();
  const userById = (id) => db.prepare('SELECT id, name FROM users WHERE id = ? AND active = 1').get(id);

  // ── shared: validate + apply changes to one lead, logging each one ──────────
  function applyChanges(lead, input, user) {
    const set = {};
    for (const f of TEXT_FIELDS) {
      if (!(f in input)) continue;
      const v = String(input[f] ?? '').trim();
      if (v !== lead[f]) set[f] = v;
    }
    for (const f of DATE_FIELDS) {
      if (!(f in input)) continue;
      const v = String(input[f] ?? '').trim();
      if (v && !DATE_RE.test(v)) throw new HttpError(400, `${label(f)} must be YYYY-MM-DD`);
      if (v !== lead[f]) set[f] = v;
    }
    if ('stage' in input && input.stage !== lead.stage) {
      if (!STAGES.includes(input.stage)) throw new HttpError(400, `Unknown stage "${input.stage}"`);
      set.stage = input.stage;
    }
    if ('quality' in input) {
      const q = input.quality || '';
      if (q && !QUALITIES.includes(q)) throw new HttpError(400, `Unknown quality "${q}"`);
      if (q !== lead.quality) set.quality = q;
    }
    let newOwner;
    if ('owner_id' in input) {
      const id = input.owner_id === null || input.owner_id === '' ? null : Number(input.owner_id);
      if (id !== null && !userById(id)) throw new HttpError(400, 'Unknown or inactive user');
      if (id !== lead.owner_id) { set.owner_id = id; newOwner = id; }
    }
    if (Object.keys(set).length === 0) return lead;

    const keyFields = ['email', 'linkedin', 'first_name', 'last_name', 'company'];
    if (keyFields.some((f) => f in set)) {
      const merged = { ...lead, ...set };
      if (!hasIdentity(merged)) throw new HttpError(400, 'A lead needs a name, email or LinkedIn');
      const key = dedupeKey(merged);
      if (key !== lead.dedupe_key) set.dedupe_key = key;
    }

    const now = new Date().toISOString();
    const cols = Object.keys(set);
    try {
      db.prepare(`UPDATE leads SET ${cols.map((c) => c + ' = ?').join(', ')}, updated_at = ? WHERE id = ?`)
        .run(...cols.map((c) => set[c]), now, lead.id);
    } catch (e) {
      if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'Another lead already has this email / LinkedIn');
      throw e;
    }

    const log = (type, note, meta) => logActivity(db, { lead_id: lead.id, user_id: user.id, type, note, meta });
    if ('stage' in set) log('stage_change', `${lead.stage} → ${set.stage}`, { from: lead.stage, to: set.stage });
    if ('quality' in set) log('quality_change', `${lead.quality || 'Unrated'} → ${set.quality || 'Unrated'}`, { from: lead.quality, to: set.quality });
    if ('meeting_date' in set) log('meeting_date', set.meeting_date ? `Meeting set for ${set.meeting_date}` : 'Meeting date cleared', { from: lead.meeting_date, to: set.meeting_date });
    if ('owner_id' in set) {
      const from = lead.owner_id ? userById(lead.owner_id)?.name || db.prepare('SELECT name FROM users WHERE id=?').get(lead.owner_id)?.name : null;
      const to = newOwner ? userById(newOwner).name : null;
      log('assign', `${from || 'Unassigned'} → ${to || 'Unassigned'}`, { from_id: lead.owner_id, to_id: newOwner });
    }
    const other = cols.filter((c) => !['stage', 'quality', 'meeting_date', 'owner_id', 'dedupe_key'].includes(c));
    if (other.length) log('edit', 'Edited: ' + other.map(label).join(', '));

    return db.prepare('SELECT * FROM leads WHERE id = ?').get(lead.id);
  }

  // ── filters shared by list / ids ────────────────────────────────────────────
  function buildWhere(q, user) {
    const where = [];
    const params = [];
    const terms = String(q.q || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
    for (const t of terms) {
      where.push("LOWER(l.first_name || ' ' || l.last_name || ' ' || l.company || ' ' || l.email || ' ' || l.title) LIKE ?");
      params.push(`%${t}%`);
    }
    if (q.owner === 'none') where.push('l.owner_id IS NULL');
    else if (q.owner === 'me') { where.push('l.owner_id = ?'); params.push(user.id); }
    else if (q.owner) { where.push('l.owner_id = ?'); params.push(Number(q.owner)); }
    if (q.stage) { where.push('l.stage = ?'); params.push(q.stage); }
    if (q.quality === 'none') where.push("l.quality = ''");
    else if (q.quality) { where.push('l.quality = ?'); params.push(q.quality); }
    if (q.source) { where.push('l.source = ?'); params.push(q.source); }
    if (q.untouched === '1') where.push("l.last_activity_at = ''");
    if (q.meeting === '1') where.push("l.meeting_date != ''");
    if (q.due === '1') { where.push("l.next_action_date != '' AND l.next_action_date <= ?"); params.push(new Date().toISOString().slice(0, 10)); }
    return { sql: where.length ? 'WHERE ' + where.join(' AND ') : '', params };
  }

  r.get('/', (req, res) => {
    const { sql, params } = buildWhere(req.query, req.user);
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 200);
    const page = Math.max(Number(req.query.page) || 1, 1);
    const sort = SORTABLE.has(req.query.sort) ? req.query.sort : 'updated_at';
    const dir = req.query.dir === 'asc' ? 'ASC' : 'DESC';
    const total = db.prepare(`SELECT COUNT(*) AS n FROM leads l ${sql}`).get(...params).n;
    const rows = db.prepare(
      `SELECT l.*, u.name AS owner_name,
              (SELECT COUNT(*) FROM activities a WHERE a.lead_id = l.id AND a.type NOT IN ('edit','assign','stage_change','quality_change','meeting_date')) AS activity_count,
              (SELECT a.type FROM activities a WHERE a.lead_id = l.id AND a.type NOT IN ('edit','assign','stage_change','quality_change','meeting_date') ORDER BY a.created_at DESC, a.id DESC LIMIT 1) AS last_type
       FROM leads l LEFT JOIN users u ON u.id = l.owner_id
       ${sql} ORDER BY l.${sort} ${dir}, l.id DESC LIMIT ? OFFSET ?`
    ).all(...params, limit, (page - 1) * limit);
    res.json({ rows, total, page, limit });
  });

  r.get('/ids', (req, res) => {
    const { sql, params } = buildWhere(req.query, req.user);
    const ids = db.prepare(`SELECT l.id FROM leads l ${sql} ORDER BY l.id LIMIT 5000`).all(...params).map((x) => x.id);
    res.json({ ids });
  });

  r.get('/facets', (_req, res) => {
    const today = new Date().toISOString().slice(0, 10);
    const one = (sql, ...p) => db.prepare(sql).get(...p).n;
    const count = (col) => Object.fromEntries(db.prepare(`SELECT ${col} AS k, COUNT(*) AS n FROM leads GROUP BY ${col}`).all().map((x) => [x.k ?? '', x.n]));
    res.json({
      total: db.prepare('SELECT COUNT(*) AS n FROM leads').get().n,
      untouched: one("SELECT COUNT(*) AS n FROM leads WHERE last_activity_at = ''"),
      meetings: one("SELECT COUNT(*) AS n FROM leads WHERE meeting_date != ''"),
      upcomingMeetings: one("SELECT COUNT(*) AS n FROM leads WHERE meeting_date >= ?", today),
      due: one("SELECT COUNT(*) AS n FROM leads WHERE next_action_date != '' AND next_action_date <= ?", today),
      stages: count('stage'),
      qualities: count('quality'),
      owners: count('owner_id'),
      sources: db.prepare("SELECT source AS k, COUNT(*) AS n FROM leads WHERE source != '' GROUP BY source ORDER BY n DESC").all(),
    });
  });

  r.post('/', (req, res) => {
    const input = req.body || {};
    const lead = Object.fromEntries(TEXT_FIELDS.map((f) => [f, String(input[f] ?? '').trim()]));
    if (!hasIdentity(lead)) throw new HttpError(400, 'Enter at least a name, email or LinkedIn');
    const key = dedupeKey(lead);
    if (db.prepare('SELECT 1 FROM leads WHERE dedupe_key = ?').get(key)) throw new HttpError(409, 'This lead already exists');
    const now = new Date().toISOString();
    const cols = [...TEXT_FIELDS, 'dedupe_key', 'owner_id', 'created_at', 'updated_at'];
    const owner = input.owner_id ? Number(input.owner_id) : req.user.id;
    const id = tx(db, () => {
      const info = db.prepare(`INSERT INTO leads(${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`)
        .run(...TEXT_FIELDS.map((f) => lead[f]), key, owner, now, now);
      logActivity(db, { lead_id: Number(info.lastInsertRowid), user_id: req.user.id, type: 'note', note: 'Lead added manually' });
      return Number(info.lastInsertRowid);
    });
    res.status(201).json({ id });
  });

  r.post('/bulk', (req, res) => {
    const { ids, set } = req.body || {};
    if (!Array.isArray(ids) || ids.length === 0) throw new HttpError(400, 'No leads selected');
    if (ids.length > 5000) throw new HttpError(400, 'Select at most 5000 leads at a time');
    const allowed = {};
    for (const k of ['owner_id', 'stage', 'quality']) if (set && k in set) allowed[k] = set[k];
    if (Object.keys(allowed).length === 0) throw new HttpError(400, 'Nothing to change');
    let changed = 0;
    tx(db, () => {
      const get = db.prepare('SELECT * FROM leads WHERE id = ?');
      for (const id of ids) {
        const lead = get.get(Number(id));
        if (!lead) continue;
        const after = applyChanges(lead, allowed, req.user);
        if (after !== lead) changed++;
      }
    });
    res.json({ changed });
  });

  r.get('/:id', (req, res) => {
    const lead = db.prepare('SELECT l.*, u.name AS owner_name FROM leads l LEFT JOIN users u ON u.id = l.owner_id WHERE l.id = ?').get(Number(req.params.id));
    if (!lead) throw new HttpError(404, 'Lead not found');
    const activities = db.prepare(
      `SELECT a.id, a.type, a.note, a.created_at, a.user_id, u.name AS user_name
       FROM activities a JOIN users u ON u.id = a.user_id
       WHERE a.lead_id = ? ORDER BY a.created_at DESC, a.id DESC LIMIT 300`
    ).all(lead.id);
    res.json({ lead, activities });
  });

  r.patch('/:id', (req, res) => {
    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(Number(req.params.id));
    if (!lead) throw new HttpError(404, 'Lead not found');
    const updated = tx(db, () => applyChanges(lead, req.body || {}, req.user));
    res.json({ lead: updated });
  });

  r.post('/:id/activities', (req, res) => {
    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(Number(req.params.id));
    if (!lead) throw new HttpError(404, 'Lead not found');
    const { type, note } = req.body || {};
    if (!(type in MANUAL_TYPES)) throw new HttpError(400, 'Unknown activity type');
    const text = String(note || '').trim();
    if (type === 'note' && !text) throw new HttpError(400, 'Write a note first');
    tx(db, () => {
      logActivity(db, { lead_id: lead.id, user_id: req.user.id, type, note: text });
      if (lead.stage === 'New' && FIRST_TOUCH_TYPES.includes(type)) {
        applyChanges(db.prepare('SELECT * FROM leads WHERE id = ?').get(lead.id), { stage: 'Contacted' }, req.user);
      }
    });
    res.status(201).json({ ok: true });
  });

  return r;
}
