// ─────────────────────────────────────────────────────────────
// All business settings live here. Edit this file to change
// stages, quality categories, timezone, etc. No other file needs
// to change — the UI reads these lists from /api/config.
// ─────────────────────────────────────────────────────────────
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const PORT = Number(process.env.PORT || 3000);
export const DATA_DIR = process.env.DATA_DIR || path.join(root, 'data');
export const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'crm.db');
export const PUBLIC_DIR = path.join(root, 'public');

// Timezone used for "today / yesterday / this week / this month".
// Asia/Dhaka is UTC+6 with no daylight saving, so a fixed offset is exact.
export const TZ = 'Asia/Dhaka';
export const TZ_OFFSET_MIN = 360;
export const WEEK_START = 1; // 0 = Sunday, 1 = Monday

// Pipeline stage: where the lead is in the process.
export const STAGES = ['New', 'Contacted', 'Replied', 'Meeting Booked', 'Meeting Done', 'Closed'];

// Quality / category: what kind of lead this turned out to be.
// '' (blank) means "not rated yet".
export const QUALITIES = [
  'Discovery Meeting',
  'Direct skillBNK Customer',
  'Strategic Partnership',
  'AI Video Content Tool',
  'AI Agent Tool',
  'Not a Fit',
];

// Activity types people can log by hand. Order = order of the buttons in the UI.
export const MANUAL_TYPES = {
  call: 'Call',
  email: 'Email',
  meeting: 'Meeting',
  note: 'Note',
  linkedin_view: 'Profile view',
  linkedin_follow: 'Follow',
  linkedin_like: 'Like',
  linkedin_comment: 'Comment',
  linkedin_connect: 'Connection request',
  linkedin_connected: 'Connected',
  linkedin_inmail: 'InMail',
  linkedin_dm: 'DM',
};

// The LinkedIn actions (shown as a group / menu in the UI).
export const LINKEDIN_TYPES = Object.keys(MANUAL_TYPES).filter((k) => k.startsWith('linkedin_'));

// Outreach "touches" = every logged action except notes.
export const TOUCH_TYPES = Object.keys(MANUAL_TYPES).filter((k) => k !== 'note');

// Everything that can appear in the activity log (manual + automatic).
export const TYPE_LABELS = {
  ...MANUAL_TYPES,
  linkedin: 'LinkedIn', // older generic type, kept so old rows still display
  stage_change: 'Stage change',
  quality_change: 'Quality change',
  assign: 'Assignment',
  meeting_date: 'Meeting date',
  edit: 'Edit',
  trashed: 'Moved to recycle bin',
  restored: 'Restored',
};

// Logging one of these on a lead that is still "New" moves it to "Contacted".
export const FIRST_TOUCH_TYPES = TOUCH_TYPES.filter((t) => t !== 'meeting');

export const DEFAULT_ADMIN = {
  name: process.env.ADMIN_NAME || 'Admin',
  email: process.env.ADMIN_EMAIL || 'admin@skillbnk.local',
  password: process.env.ADMIN_PASSWORD || 'admin123',
};

// Team members created automatically on startup if they don't exist yet.
// Emails are placeholders: edit them (and reset passwords) in the Team page.
export const TEAM = [
  { name: 'Tawhid', email: 'tawhid@skillbnk.local' },
  { name: 'Ahana Anjum', email: 'ahana@skillbnk.local' },
  { name: 'Safiul Alom', email: 'safiul@skillbnk.local' },
];
export const TEAM_DEFAULT_PASSWORD = process.env.TEAM_PASSWORD || 'welcome123';
