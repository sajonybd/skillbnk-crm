import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

process.env.SESSION_SECRET = 'test-secret';
const { openDb } = await import('../server/db.js');
const { createApp } = await import('../server/app.js');
const { seedAdmin } = await import('../server/auth.js');
const { rangeBounds } = await import('../server/lib/range.js');

let server;
let base;
let cookie = '';

async function call(method, url, body, ck = cookie) {
  const res = await fetch(base + url, {
    method,
    headers: { 'content-type': 'application/json', cookie: ck },
    body: body ? JSON.stringify(body) : undefined,
  });
  const set = res.headers.get('set-cookie');
  if (set) cookie = set.split(';')[0];
  const json = await res.json().catch(() => ({}));
  return { status: res.status, ...json };
}

before(async () => {
  const db = openDb(':memory:');
  seedAdmin(db);
  server = createApp(db).listen(0);
  base = `http://localhost:${server.address().port}`;
});
after(() => server.close());

// Same shape as the "Master Leads" tab: 2 title rows, then the header.
const MASTER = `skillBNK MASTER LEADS — CLEAN CRM V2
Current state of every lead
First Name,Last Name,Title,Company,Email,Email Status,LinkedIn,Company LinkedIn,Website,# Employees,Industry,State,Country,Source / List,Owner,Research Status,Qualification,Pipeline Stage
Sam,Parr,Co-Founder,Hampton,sam@joinhampton.com,Verified,http://www.linkedin.com/in/parrsam,http://www.linkedin.com/company/myhampton,https://joinhampton.com,16,think tanks,New York,United States,USA Batch 001,Ahana Anjum,Not Reviewed,Batch 01 Screened,New
Pete,Widry,"Founder, CEO",P6 Aviation,pete@p6aviation.com,Verified,http://www.linkedin.com/in/petewidry,,https://p6aviation.com,13,airlines/aviation,New York,United States,USA Batch 001,Tawhid,Not Reviewed,Batch 01 Screened,New
`;

// Same shape as "Apollo New Leads": no owner column.
const APOLLO = `First Name,Last Name,Title,Company,Email,Email Status,LinkedIn,Website,City,State,ICP Segment,Geo,Apollo Contact ID
Nichole,Bradford,Training and Development Manager,Class Valuation,nbradford@classvaluation.com,verified,linkedin.com/in/nichole-bradford-209a88a5,classvaluation.com,Troy,Michigan,L&D Employers,MI,6ac3a3ffa18872000c187222
Elizabeth,Bull-Davie,Training and Development Manager,"Niles Industrial Coatings, LLC",elizabethbulldavie@nilesindustrial.com,verified,linkedin.com/in/elizabeth-bull-davie-detroit,nilesindustrial.com,South Lyon,Michigan,L&D Employers,MI,6ac3a3ffa18872000c187225
Gracie,Corbin,Training & Development Manager,AMP Residential,gcorbin@ampresidential.com,verified,linkedin.com/in/gracie-corbin,ampresidential.com,Grand Rapids,Michigan,L&D Employers,MI,6ac3a3ffa18872000c187218
`;

test('requires login', async () => {
  const r = await call('GET', '/api/leads', null, '');
  assert.equal(r.status, 401);
});

test('login + bad password', async () => {
  const bad = await call('POST', '/api/login', { email: 'admin@skillbnk.local', password: 'nope' }, '');
  assert.equal(bad.status, 401);
  const ok = await call('POST', '/api/login', { email: 'admin@skillbnk.local', password: 'admin123' });
  assert.equal(ok.status, 200);
  assert.equal(ok.user.role, 'admin');
});

test('import preview detects header row below title rows', async () => {
  const p = await call('POST', '/api/import/preview', { text: MASTER });
  assert.equal(p.status, 200);
  assert.equal(p.totalRows, 2);
  assert.equal(p.newCount, 2);
  assert.ok(p.mapping.includes('owner'));
  assert.equal(p.mapping[p.headers.indexOf('# Employees')], 'employees');
});

test('import Master Leads: auto-creates owners, skips unknown stage text', async () => {
  const p = await call('POST', '/api/import/preview', { text: MASTER });
  const c = await call('POST', '/api/import/commit', { text: MASTER, mapping: p.mapping, source: 'x', assign: { mode: 'none' } });
  assert.equal(c.created, 2);
  assert.deepEqual(c.createdUsers.sort(), ['Ahana Anjum', 'Tawhid']);
  const list = await call('GET', '/api/leads?owner=none');
  assert.equal(list.total, 0);
  const all = await call('GET', '/api/leads');
  const pete = all.rows.find((l) => l.first_name === 'Pete');
  assert.equal(pete.title, 'Founder, CEO');
  assert.equal(pete.owner_name, 'Tawhid');
  assert.equal(pete.stage, 'New');
  assert.equal(pete.quality, '');
  assert.equal(pete.employees, '13');
});

test('re-importing the same file creates no duplicates', async () => {
  const p = await call('POST', '/api/import/preview', { text: MASTER });
  assert.equal(p.newCount, 0);
  assert.equal(p.duplicateCount, 2);
  const c = await call('POST', '/api/import/commit', { text: MASTER, mapping: p.mapping, assign: { mode: 'none' } });
  assert.equal(c.created, 0);
  assert.equal(c.duplicates, 2);
});

test('Apollo import split evenly across team', async () => {
  const team = await call('GET', '/api/team');
  const ids = team.users.filter((u) => ['Ahana Anjum', 'Tawhid'].includes(u.name)).map((u) => u.id);
  const p = await call('POST', '/api/import/preview', { text: APOLLO });
  const c = await call('POST', '/api/import/commit', { text: APOLLO, mapping: p.mapping, source: 'Apollo Oct 5', assign: { mode: 'split', user_ids: ids } });
  assert.equal(c.created, 3);
  const counts = Object.values(c.byOwner).sort();
  assert.deepEqual(counts, [1, 2]);
  const all = await call('GET', '/api/leads?source=' + encodeURIComponent('Apollo Oct 5'));
  assert.equal(all.total, 3);
});

test('assigning logs activity; reassigning logs again', async () => {
  const all = await call('GET', '/api/leads');
  const lead = all.rows[0];
  const team = await call('GET', '/api/team');
  const admin = team.users.find((u) => u.role === 'admin');
  const a = await call('PATCH', `/api/leads/${lead.id}`, { owner_id: admin.id });
  assert.equal(a.status, 200);
  const d = await call('GET', `/api/leads/${lead.id}`);
  const assign = d.activities.find((x) => x.type === 'assign');
  assert.ok(assign);
  assert.match(assign.note, /→ Admin$/);
  assert.equal(assign.user_name, 'Admin');
});

test('stage / quality changes are validated and logged; first touch auto-moves New→Contacted', async () => {
  const all = await call('GET', '/api/leads?q=bradford');
  const id = all.rows[0].id;
  const bad = await call('PATCH', `/api/leads/${id}`, { stage: 'Banana' });
  assert.equal(bad.status, 400);
  const bad2 = await call('PATCH', `/api/leads/${id}`, { quality: 'Meh' });
  assert.equal(bad2.status, 400);

  const log = await call('POST', `/api/leads/${id}/activities`, { type: 'call', note: 'Left voicemail' });
  assert.equal(log.status, 201);
  let d = await call('GET', `/api/leads/${id}`);
  assert.equal(d.lead.stage, 'Contacted');

  await call('PATCH', `/api/leads/${id}`, { quality: 'Strategic Partnership', meeting_date: '2026-11-10' });
  d = await call('GET', `/api/leads/${id}`);
  const types = d.activities.map((x) => x.type);
  for (const t of ['call', 'stage_change', 'quality_change', 'meeting_date']) assert.ok(types.includes(t), t);
});

test('bulk assign + stage', async () => {
  const ids = (await call('GET', '/api/leads/ids')).ids;
  assert.equal(ids.length, 5);
  const team = await call('GET', '/api/team');
  const t = team.users.find((u) => u.name === 'Tawhid');
  const r = await call('POST', '/api/leads/bulk', { ids, set: { owner_id: t.id, stage: 'Replied' } });
  assert.equal(r.status, 200);
  const list = await call('GET', `/api/leads?owner=${t.id}&stage=Replied`);
  assert.equal(list.total, 5);
});

test('activity log: today summary per user, filter by user and type', async () => {
  const a = await call('GET', '/api/activity?range=today');
  assert.ok(a.total > 0);
  const admin = a.summary.find((s) => s.user_name === 'Admin');
  assert.ok(admin.types.call >= 1);
  assert.ok(admin.leads >= 1);
  const calls = await call('GET', '/api/activity?range=today&type=call');
  assert.ok(calls.rows.every((r) => r.type === 'call'));
  const yest = await call('GET', '/api/activity?range=yesterday');
  assert.equal(yest.total, 0);
});

test('duplicate email edit is rejected', async () => {
  const all = await call('GET', '/api/leads');
  const [a, b] = all.rows;
  const r = await call('PATCH', `/api/leads/${a.id}`, { email: b.email });
  assert.equal(r.status, 409);
});

test('team: member cannot create users; admin can', async () => {
  const mk = await call('POST', '/api/team', { name: 'Safiul Alom', email: 'safiul@skillbnk.local', password: 'secret1', role: 'member' });
  assert.equal(mk.status, 201);
  const memberCookie = await (async () => {
    const res = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'safiul@skillbnk.local', password: 'secret1' }) });
    return res.headers.get('set-cookie').split(';')[0];
  })();
  const denied = await call('POST', '/api/team', { name: 'X', email: 'x@x.com', password: 'secret1' }, memberCookie);
  assert.equal(denied.status, 403);
});

test('date ranges in Asia/Dhaka', () => {
  // 2026-11-04 17:03 Dhaka = 11:03 UTC (a Wednesday)
  const now = Date.parse('2026-11-04T11:03:00Z');
  assert.deepEqual(rangeBounds('today', '', '', now), { start: '2026-11-03T18:00:00.000Z', end: '2026-11-04T18:00:00.000Z' });
  assert.equal(rangeBounds('yesterday', '', '', now).start, '2026-11-02T18:00:00.000Z');
  assert.equal(rangeBounds('week', '', '', now).start, '2026-11-01T18:00:00.000Z'); // Monday Nov 2, 00:00 Dhaka
  assert.equal(rangeBounds('month', '', '', now).start, '2026-10-31T18:00:00.000Z');
  assert.equal(rangeBounds('last_month', '', '', now).start, '2026-09-30T18:00:00.000Z');
});

test('analytics: tabs + daily breakdown by team member, linkedin action types', async () => {
  const all = await call('GET', '/api/leads?q=bradford');
  const id = all.rows[0].id;
  for (const type of ['linkedin_view', 'linkedin_connect', 'linkedin_dm']) {
    const r = await call('POST', `/api/leads/${id}/activities`, { type });
    assert.equal(r.status, 201, type);
  }
  const list = await call('GET', '/api/leads?q=bradford');
  assert.ok(list.rows[0].activity_count >= 4);
  assert.equal(list.rows[0].last_type, 'linkedin_dm');

  const tabs = await call('GET', '/api/activity/tabs');
  assert.ok(tabs.today >= 4);
  assert.equal(tabs.yesterday, 0);
  assert.ok(tabs.all >= tabs.today);

  const daily = await call('GET', '/api/activity/daily?range=month');
  assert.ok(daily.days.length >= 1);
  const day = daily.days[0];
  assert.match(day.day, /^\d{4}-\d{2}-\d{2}$/);
  const admin = Object.values(day.byUser).find((u) => u.user_name === 'Admin');
  assert.ok(admin.touches >= 4);
  assert.ok(admin.types.linkedin_dm >= 1);

  const team = await call('GET', '/api/team');
  const other = team.users.find((u) => u.name === 'Tawhid');
  const filtered = await call('GET', `/api/activity/daily?range=month&user=${other.id}`);
  assert.ok(filtered.days.every((d) => Object.keys(d.byUser).every((k) => Number(k) === other.id)));

  const fac = await call('GET', '/api/leads/facets');
  assert.equal(typeof fac.untouched, 'number');
  const untouched = await call('GET', '/api/leads?untouched=1');
  assert.equal(untouched.total, fac.untouched);
});

test('recycle bin: delete → bin → restore, purge only from the bin, admin only', async () => {
  const adminCookie = cookie;
  const memberCookie = await (async () => {
    const res = await fetch(base + '/api/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'safiul@skillbnk.local', password: 'secret1' }) });
    return res.headers.get('set-cookie').split(';')[0];
  })();
  const all = await call('GET', '/api/leads?limit=200');
  const before = all.total;
  const [a, b, c] = all.rows;

  // members can't delete, see the bin, restore or purge
  assert.equal((await call('DELETE', `/api/leads/${a.id}`, null, memberCookie)).status, 403);
  assert.equal((await call('POST', '/api/leads/bulk-delete', { ids: [a.id] }, memberCookie)).status, 403);
  assert.equal((await call('GET', '/api/leads/trash', null, memberCookie)).status, 403);
  assert.equal((await call('POST', '/api/leads/restore', { ids: [a.id] }, memberCookie)).status, 403);
  assert.equal((await call('POST', '/api/leads/purge', { ids: [a.id] }, memberCookie)).status, 403);

  // delete = move to bin: gone from lists/counts, history kept
  assert.equal((await call('DELETE', `/api/leads/${a.id}`, null, adminCookie)).status, 200);
  assert.equal((await call('DELETE', `/api/leads/${a.id}`, null, adminCookie)).status, 404, 'already in bin');
  assert.equal((await call('POST', '/api/leads/bulk-delete', { ids: [b.id, c.id] }, adminCookie)).deleted, 2);
  assert.equal((await call('GET', '/api/leads')).total, before - 3);
  const fac = await call('GET', '/api/leads/facets');
  assert.equal(fac.total, before - 3);
  assert.equal(fac.trash, 3);
  const bin = await call('GET', '/api/leads/trash');
  assert.equal(bin.total, 3);
  assert.equal(bin.rows[0].deleted_by_name, 'Admin');
  assert.ok(bin.rows[0].deleted_at);

  // a trashed lead is read-only and can't be edited or logged against
  assert.equal((await call('PATCH', `/api/leads/${a.id}`, { stage: 'Replied' })).status, 400);
  assert.equal((await call('POST', `/api/leads/${a.id}/activities`, { type: 'call' })).status, 400);
  assert.equal((await call('GET', `/api/leads/${a.id}`)).lead.deleted_at.length > 0, true);

  // re-importing a trashed lead is skipped and reported as "in bin"
  const row = (await call('GET', `/api/leads/${a.id}`)).lead;
  const csv = `First Name,Last Name,Email,Company\n${row.first_name},${row.last_name},${row.email},${row.company}\n`;
  if (row.email) {
    const pv = await call('POST', '/api/import/preview', { text: csv });
    assert.equal(pv.trashedCount, 1);
    assert.equal(pv.newCount, 0);
  }

  // restore one → back in the list with a history entry
  assert.equal((await call('POST', '/api/leads/restore', { ids: [a.id] })).restored, 1);
  assert.equal((await call('GET', '/api/leads')).total, before - 2);
  const hist = await call('GET', `/api/leads/${a.id}`);
  assert.deepEqual(hist.activities.filter((x) => ['trashed', 'restored'].includes(x.type)).map((x) => x.type).sort(), ['restored', 'trashed']);

  // purge refuses leads that aren't in the bin, and removes binned ones for good
  assert.equal((await call('POST', '/api/leads/purge', { ids: [a.id] })).purged, 0);
  assert.equal((await call('POST', '/api/leads/purge', { ids: [b.id] })).purged, 1);
  assert.equal((await call('GET', `/api/leads/${b.id}`)).status, 404);
  assert.equal((await call('GET', '/api/leads/trash')).total, 1);

  // empty the bin
  assert.equal((await call('POST', '/api/leads/purge', { all: true })).purged, 1);
  assert.equal((await call('GET', '/api/leads/trash')).total, 0);
  assert.equal((await call('GET', '/api/leads')).total, before - 2);
});

test('migration: an old database without deleted_at is upgraded in place', async () => {
  const fs = await import('node:fs');
  const os = await import('node:os');
  const path = await import('node:path');
  const file = path.join(os.tmpdir(), `crm-old-${Date.now()}.db`);
  // Build a database exactly as the previous version made it: current schema minus the recycle-bin columns.
  const first = openDb(file);
  first.exec('DROP INDEX idx_leads_deleted; ALTER TABLE leads DROP COLUMN deleted_at; ALTER TABLE leads DROP COLUMN deleted_by;');
  first.exec("INSERT INTO leads(first_name, dedupe_key, created_at, updated_at) VALUES ('Old', 'e:old@x.com', 'x', 'x')");
  assert.ok(!first.prepare('PRAGMA table_info(leads)').all().some((c) => c.name === 'deleted_at'));
  first.close();

  const upgraded = openDb(file); // runs the migration
  const lead = upgraded.prepare('SELECT first_name, deleted_at, deleted_by FROM leads').get();
  assert.equal(lead.first_name, 'Old');
  assert.equal(lead.deleted_at, '');
  assert.equal(lead.deleted_by, null);
  upgraded.close();
  openDb(file).close(); // and is safe to run again
  for (const ext of ['', '-wal', '-shm']) fs.rmSync(file + ext, { force: true });
});
