import { api, setUnauthorizedHandler } from './api.js';
import { h, setTz, toast, registerPeople } from './util.js';
import * as login from './views/login.js';
import * as leads from './views/leads.js';
import * as analytics from './views/analytics.js';
import { icon } from './icons.js';
import * as importer from './views/import.js';
import * as team from './views/team.js';
import * as trash from './views/trash.js';

// To add a page: create views/yourpage.js exporting render(root, ctx), then add a line here.
const PAGES = [
  { path: 'leads', label: 'Leads', icon: 'users', view: leads },
  { path: 'analytics', label: 'Analytics', icon: 'chart', view: analytics },
  { path: 'import', label: 'Import', icon: 'inbox', view: importer },
  { path: 'team', label: 'Team', icon: 'userCheck', view: team, adminOnly: true },
  { path: 'trash', label: 'Recycle bin', icon: 'trash', view: trash, adminOnly: true },
];

const app = document.getElementById('app');
const ctx = { user: null, config: null, users: [], reloadUsers: null };

async function boot() {
  setUnauthorizedHandler(() => { ctx.user = null; showLogin(); });
  try {
    ctx.user = (await api('GET', '/api/me')).user;
  } catch {
    return showLogin();
  }
  await start();
}

function showLogin() {
  login.render(app, async (user) => { ctx.user = user; await start(); });
}

async function start() {
  ctx.config = await api('GET', '/api/config');
  setTz(ctx.config.tz);
  ctx.reloadUsers = async () => { ctx.users = (await api('GET', '/api/team')).users; registerPeople(ctx.users); };
  await ctx.reloadUsers();
  window.addEventListener('hashchange', route);
  route();
}

async function route() {
  if (!ctx.user) return;
  const path = location.hash.replace(/^#\/?/, '') || 'leads';
  const pages = PAGES.filter((p) => !p.adminOnly || ctx.user.role === 'admin');
  const page = pages.find((p) => p.path === path) || pages[0];

  const main = h('main', { class: 'page' });
  app.replaceChildren(topbar(pages, page), main);
  try {
    await page.view.render(main, ctx);
  } catch (e) {
    main.replaceChildren(h('div', { class: 'card empty' }, 'Could not load this page: ' + e.message));
  }
}

function topbar(pages, active) {
  return h('header', { class: 'topbar' },
    h('div', { class: 'brand' }, h('span', { class: 'logo' }, 'SB'), 'skillBNK CRM'),
    h('nav', { class: 'nav row' }, pages.map((p) => h('a', { href: '#/' + p.path, class: p === active ? 'active' : '' }, icon(p.icon, 16), p.label))),
    h('div', { class: 'spacer' }),
    h('span', { class: 'muted' }, ctx.user.name),
    h('button', { class: 'btn small', onclick: changePassword }, 'Password'),
    h('button', { class: 'btn small', onclick: async () => { await api('POST', '/api/logout'); ctx.user = null; showLogin(); } }, 'Sign out'),
  );
}

async function changePassword() {
  const current = prompt('Current password:');
  if (current == null) return;
  const next = prompt('New password (min 6 characters):');
  if (next == null) return;
  try { await api('POST', '/api/me/password', { current, next }); toast('Password changed'); }
  catch (e) { toast(e.message, true); }
}

boot();
